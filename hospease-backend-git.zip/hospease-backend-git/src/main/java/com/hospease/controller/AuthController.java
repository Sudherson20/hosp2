package com.hospease.controller;

import com.hospease.requestdto.LoginRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.AuthResponse;
import com.hospease.responsedto.UserResponse;
import com.hospease.service.AuthService;
import com.hospease.service.UserService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final UserService userService;

    @PostMapping("/login")
    public ApiResponse<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return ApiResponse.success("Login successful.", authService.login(request));
    }

    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public ApiResponse<UserResponse> me() {
        return ApiResponse.success("Current user fetched successfully.", userService.mapToResponse(SecurityUtils.getCurrentUser()));
    }
}
