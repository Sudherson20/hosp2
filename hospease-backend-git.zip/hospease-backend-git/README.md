# HospEase Backend

Spring Boot backend for the `HospEase` hospitality property and guest management system.

## Run

```powershell
cd "C:\Users\Sudherson C\Documents\New project\hospease-backend"
cmd /c "set JAVA_HOME=C:\Program Files\Java\jdk-21&& apache-maven-3.9.14\bin\mvn.cmd -Dmaven.repo.local=.m2\repository spring-boot:run"
```

Default port: `8090`

Swagger UI:

`http://localhost:8090/swagger-ui.html`

H2 console:

`http://localhost:8090/h2-console`

JDBC URL: `jdbc:h2:mem:hospease`

## Seed users

All seeded passwords except admin: `Password@123`

Admin password default: `Admin@123`

- `admin@hospease.local`
- `manager@hospease.local`
- `frontdesk@hospease.local`
- `housekeeping@hospease.local`
- `service@hospease.local`
- `finance@hospease.local`
- `auditor@hospease.local`
- `guest@hospease.local`

## Main modules

- Auth and users
- Guests
- Staff and shifts
- Rooms
- Reservations
- Housekeeping tasks
- Service orders
- Invoices without payment gateway implementation
- Reporting only for module 7
- Notifications
- Tasks
- Audit logs

## Notes

- Payment processing is intentionally not implemented.
- KPI and audit package generation are intentionally not implemented.
- Switch to MySQL by running with profile `mysql` and setting `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD`.
