# backend_hospease

Spring Boot backend for the `HospEase` hospitality property and guest management system.

## Run

```powershell
cd "C:\Users\Sudherson C\Documents\New project\backend_hospease"
.\mvnw.cmd spring-boot:run
```

Default port: `8090`

Swagger UI:

`http://localhost:8090/swagger-ui.html`

## MySQL

Default database config now uses MySQL directly:

- URL: `jdbc:mysql://localhost:3306/hospease`
- Username: `root`
- Password: `root`

You can override them with environment variables:

- `DB_URL`
- `DB_USERNAME`
- `DB_PASSWORD`

Example:

```powershell
$env:DB_URL="jdbc:mysql://localhost:3306/hospease?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata"
$env:DB_USERNAME="root"
$env:DB_PASSWORD="your_mysql_password"
.\mvnw.cmd spring-boot:run
```

You can inspect everything in MySQL Workbench after sending requests from Postman.

## Seed users

All seeded passwords except admin: `Password@123`

Admin password default: `Admin@123`

- `admin@hospease.local`
- `manager@hospease.local`
- `frontdesk@hospease.local`
- `housekeeping@hospease.local`
- `service@hospease.local`
- `finance@hospease.local`
- `auditor@hospease.local`
- `guest@hospease.local`

## First Postman APIs

Register a new guest:

`POST /api/v1/auth/register`

```json
{
  "name": "Arun Kumar",
  "email": "arun@example.com",
  "phone": "9876543210",
  "password": "Arun@12345",
  "dateOfBirth": "1998-06-12",
  "addressJson": "{\"city\":\"Chennai\",\"country\":\"India\"}"
}
```

Login:

`POST /api/v1/auth/login`

```json
{
  "email": "admin@hospease.local",
  "password": "Admin@123"
}
```

After login, send the JWT token in:

`Authorization: Bearer <token>`

## Main modules

- Auth and users
- Guests
- Staff and shifts
- Rooms
- Reservations
- Housekeeping tasks
- Service orders
- Invoices without payment gateway implementation
- Reporting only for module 7
- Notifications
- Tasks
- Audit logs

## Notes

- Payment processing is intentionally not implemented.
- KPI and audit package generation are intentionally not implemented.
- Main runtime is MySQL only.
