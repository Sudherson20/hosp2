package com.hospease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospeaseBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
