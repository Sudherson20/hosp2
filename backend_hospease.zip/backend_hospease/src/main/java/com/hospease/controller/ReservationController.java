package com.hospease.controller;

import com.hospease.requestdto.ReservationRequest;
import com.hospease.requestdto.ReservationStatusRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.ReservationResponse;
import com.hospease.service.ReservationService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/reservations")
@RequiredArgsConstructor
public class ReservationController {

    private final ReservationService reservationService;

    @GetMapping
    @PreAuthorize("hasAuthority('RESERVATION_READ')")
    public ApiResponse<List<ReservationResponse>> findAll() {
        return ApiResponse.success("Reservations fetched successfully.", reservationService.findAllForUser(SecurityUtils.getCurrentUser()));
    }

    @GetMapping("/{reservationId}")
    @PreAuthorize("hasAuthority('RESERVATION_READ')")
    public ApiResponse<ReservationResponse> findById(@PathVariable Long reservationId) {
        return ApiResponse.success("Reservation fetched successfully.", reservationService.findById(reservationId, SecurityUtils.getCurrentUser()));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('RESERVATION_WRITE')")
    public ApiResponse<ReservationResponse> create(@Valid @RequestBody ReservationRequest request) {
        return ApiResponse.success("Reservation created successfully.", reservationService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{reservationId}")
    @PreAuthorize("hasAuthority('RESERVATION_WRITE')")
    public ApiResponse<ReservationResponse> update(@PathVariable Long reservationId, @Valid @RequestBody ReservationRequest request) {
        return ApiResponse.success("Reservation updated successfully.", reservationService.update(reservationId, request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{reservationId}/status")
    @PreAuthorize("hasAuthority('RESERVATION_CHECKIN') or hasRole('ADMIN') or hasRole('MANAGER')")
    public ApiResponse<ReservationResponse> updateStatus(@PathVariable Long reservationId, @Valid @RequestBody ReservationStatusRequest request) {
        return ApiResponse.success("Reservation status updated successfully.", reservationService.updateStatus(reservationId, request, SecurityUtils.getCurrentUser()));
    }
}
