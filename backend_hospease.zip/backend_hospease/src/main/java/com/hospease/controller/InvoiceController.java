package com.hospease.controller;

import com.hospease.requestdto.InvoiceRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.InvoiceResponse;
import com.hospease.service.InvoiceService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;

    @GetMapping
    @PreAuthorize("hasAuthority('INVOICE_READ')")
    public ApiResponse<List<InvoiceResponse>> findAll() {
        return ApiResponse.success("Invoices fetched successfully.", invoiceService.findAllForUser(SecurityUtils.getCurrentUser()));
    }

    @GetMapping("/{invoiceId}")
    @PreAuthorize("hasAuthority('INVOICE_READ')")
    public ApiResponse<InvoiceResponse> findById(@PathVariable Long invoiceId) {
        return ApiResponse.success("Invoice fetched successfully.", invoiceService.findById(invoiceId, SecurityUtils.getCurrentUser()));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('INVOICE_WRITE')")
    public ApiResponse<InvoiceResponse> create(@Valid @RequestBody InvoiceRequest request) {
        return ApiResponse.success("Invoice created successfully.", invoiceService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{invoiceId}")
    @PreAuthorize("hasAuthority('INVOICE_WRITE')")
    public ApiResponse<InvoiceResponse> update(@PathVariable Long invoiceId, @Valid @RequestBody InvoiceRequest request) {
        return ApiResponse.success("Invoice updated successfully.", invoiceService.update(invoiceId, request, SecurityUtils.getCurrentUser()));
    }
}
