package com.hospease.controller;

import com.hospease.requestdto.ChangePasswordRequest;
import com.hospease.requestdto.CreateUserRequest;
import com.hospease.requestdto.UpdateUserRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.UserResponse;
import com.hospease.service.UserService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping
    @PreAuthorize("hasAuthority('USER_READ')")
    public ApiResponse<List<UserResponse>> findAll() {
        return ApiResponse.success("Users fetched successfully.", userService.findAll());
    }

    @GetMapping("/{userId}")
    @PreAuthorize("hasAuthority('USER_READ')")
    public ApiResponse<UserResponse> findById(@PathVariable Long userId) {
        return ApiResponse.success("User fetched successfully.", userService.findById(userId));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('USER_WRITE')")
    public ApiResponse<UserResponse> create(@Valid @RequestBody CreateUserRequest request) {
        return ApiResponse.success("User created successfully.", userService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{userId}")
    @PreAuthorize("hasAuthority('USER_WRITE')")
    public ApiResponse<UserResponse> update(@PathVariable Long userId, @Valid @RequestBody UpdateUserRequest request) {
        return ApiResponse.success("User updated successfully.", userService.update(userId, request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{userId}/password")
    @PreAuthorize("hasAuthority('USER_WRITE') or authentication.principal.id == #userId")
    public ApiResponse<Void> changePassword(@PathVariable Long userId, @Valid @RequestBody ChangePasswordRequest request) {
        userService.changePassword(userId, request, SecurityUtils.getCurrentUser());
        return ApiResponse.success("Password updated successfully.", null);
    }
}
