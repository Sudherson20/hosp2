package com.hospease.controller;

import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.AuditLogResponse;
import com.hospease.service.AuditLogService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/audit-logs")
@RequiredArgsConstructor
public class AuditLogController {

    private final AuditLogService auditLogService;

    @GetMapping
    @PreAuthorize("hasAuthority('AUDIT_LOG_READ')")
    public ApiResponse<List<AuditLogResponse>> findAll() {
        return ApiResponse.success("Audit logs fetched successfully.", auditLogService.findAll());
    }
}
