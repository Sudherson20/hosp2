package com.hospease.controller;

import com.hospease.requestdto.GuestRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.GuestResponse;
import com.hospease.service.GuestService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/guests")
@RequiredArgsConstructor
public class GuestController {

    private final GuestService guestService;

    @GetMapping
    @PreAuthorize("hasAuthority('GUEST_READ')")
    public ApiResponse<List<GuestResponse>> findAll() {
        return ApiResponse.success("Guests fetched successfully.", guestService.findAll());
    }

    @GetMapping("/{guestId}")
    @PreAuthorize("hasAuthority('GUEST_READ')")
    public ApiResponse<GuestResponse> findById(@PathVariable Long guestId) {
        return ApiResponse.success("Guest fetched successfully.", guestService.findById(guestId));
    }

    @GetMapping("/me")
    @PreAuthorize("hasAnyRole('GUEST','FRONT_DESK','MANAGER','ADMIN')")
    public ApiResponse<GuestResponse> me() {
        return ApiResponse.success("Guest profile fetched successfully.", guestService.findByCurrentUser(SecurityUtils.getCurrentUser().getId()));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('GUEST_WRITE')")
    public ApiResponse<GuestResponse> create(@Valid @RequestBody GuestRequest request) {
        return ApiResponse.success("Guest created successfully.", guestService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{guestId}")
    @PreAuthorize("hasAuthority('GUEST_WRITE')")
    public ApiResponse<GuestResponse> update(@PathVariable Long guestId, @Valid @RequestBody GuestRequest request) {
        return ApiResponse.success("Guest updated successfully.", guestService.update(guestId, request, SecurityUtils.getCurrentUser()));
    }
}
