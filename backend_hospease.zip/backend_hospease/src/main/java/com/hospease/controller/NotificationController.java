package com.hospease.controller;

import com.hospease.requestdto.NotificationRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.NotificationResponse;
import com.hospease.service.NotificationService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping
    @PreAuthorize("hasAuthority('NOTIFICATION_READ')")
    public ApiResponse<List<NotificationResponse>> findAll() {
        return ApiResponse.success("Notifications fetched successfully.", notificationService.findAllForUser(SecurityUtils.getCurrentUser()));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('NOTIFICATION_WRITE')")
    public ApiResponse<NotificationResponse> create(@Valid @RequestBody NotificationRequest request) {
        return ApiResponse.success("Notification created successfully.", notificationService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{notificationId}/read")
    @PreAuthorize("hasAuthority('NOTIFICATION_READ')")
    public ApiResponse<NotificationResponse> markAsRead(@PathVariable Long notificationId) {
        return ApiResponse.success("Notification marked as read.", notificationService.markAsRead(notificationId, SecurityUtils.getCurrentUser()));
    }
}
