package com.hospease.controller;

import com.hospease.requestdto.TaskRequest;
import com.hospease.requestdto.TaskStatusRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.TaskResponse;
import com.hospease.service.TaskService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;

    @GetMapping
    @PreAuthorize("hasAuthority('TASK_READ')")
    public ApiResponse<List<TaskResponse>> findAll() {
        return ApiResponse.success("Tasks fetched successfully.", taskService.findAllForUser(SecurityUtils.getCurrentUser()));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('TASK_WRITE')")
    public ApiResponse<TaskResponse> create(@Valid @RequestBody TaskRequest request) {
        return ApiResponse.success("Task created successfully.", taskService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{taskId}")
    @PreAuthorize("hasAuthority('TASK_WRITE')")
    public ApiResponse<TaskResponse> update(@PathVariable Long taskId, @Valid @RequestBody TaskRequest request) {
        return ApiResponse.success("Task updated successfully.", taskService.update(taskId, request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{taskId}/status")
    @PreAuthorize("hasAuthority('TASK_WRITE')")
    public ApiResponse<TaskResponse> updateStatus(@PathVariable Long taskId, @Valid @RequestBody TaskStatusRequest request) {
        return ApiResponse.success("Task status updated successfully.", taskService.updateStatus(taskId, request, SecurityUtils.getCurrentUser()));
    }
}
