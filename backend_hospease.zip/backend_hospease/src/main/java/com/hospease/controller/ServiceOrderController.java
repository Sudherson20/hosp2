package com.hospease.controller;

import com.hospease.requestdto.ServiceOrderRequest;
import com.hospease.requestdto.ServiceOrderStatusRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.ServiceOrderResponse;
import com.hospease.service.ServiceOrderService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/service-orders")
@RequiredArgsConstructor
public class ServiceOrderController {

    private final ServiceOrderService serviceOrderService;

    @GetMapping
    @PreAuthorize("hasAuthority('SERVICE_ORDER_READ')")
    public ApiResponse<List<ServiceOrderResponse>> findAll() {
        return ApiResponse.success("Service orders fetched successfully.", serviceOrderService.findAllForUser(SecurityUtils.getCurrentUser()));
    }

    @GetMapping("/{orderId}")
    @PreAuthorize("hasAuthority('SERVICE_ORDER_READ')")
    public ApiResponse<ServiceOrderResponse> findById(@PathVariable Long orderId) {
        return ApiResponse.success("Service order fetched successfully.", serviceOrderService.findById(orderId, SecurityUtils.getCurrentUser()));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SERVICE_ORDER_WRITE')")
    public ApiResponse<ServiceOrderResponse> create(@Valid @RequestBody ServiceOrderRequest request) {
        return ApiResponse.success("Service order created successfully.", serviceOrderService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{orderId}")
    @PreAuthorize("hasAuthority('SERVICE_ORDER_WRITE')")
    public ApiResponse<ServiceOrderResponse> update(@PathVariable Long orderId, @Valid @RequestBody ServiceOrderRequest request) {
        return ApiResponse.success("Service order updated successfully.", serviceOrderService.update(orderId, request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{orderId}/status")
    @PreAuthorize("hasAuthority('SERVICE_ORDER_WRITE')")
    public ApiResponse<ServiceOrderResponse> updateStatus(@PathVariable Long orderId, @Valid @RequestBody ServiceOrderStatusRequest request) {
        return ApiResponse.success("Service order status updated successfully.", serviceOrderService.updateStatus(orderId, request, SecurityUtils.getCurrentUser()));
    }
}
