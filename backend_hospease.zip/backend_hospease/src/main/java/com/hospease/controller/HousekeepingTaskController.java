package com.hospease.controller;

import com.hospease.requestdto.HousekeepingTaskRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.HousekeepingTaskResponse;
import com.hospease.service.HousekeepingTaskService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/housekeeping-tasks")
@RequiredArgsConstructor
public class HousekeepingTaskController {

    private final HousekeepingTaskService housekeepingTaskService;

    @GetMapping
    @PreAuthorize("hasAuthority('HOUSEKEEPING_READ')")
    public ApiResponse<List<HousekeepingTaskResponse>> findAll() {
        return ApiResponse.success("Housekeeping tasks fetched successfully.", housekeepingTaskService.findAllForUser(SecurityUtils.getCurrentUser()));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('HOUSEKEEPING_WRITE')")
    public ApiResponse<HousekeepingTaskResponse> create(@Valid @RequestBody HousekeepingTaskRequest request) {
        return ApiResponse.success("Housekeeping task created successfully.", housekeepingTaskService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{taskId}")
    @PreAuthorize("hasAuthority('HOUSEKEEPING_WRITE')")
    public ApiResponse<HousekeepingTaskResponse> update(@PathVariable Long taskId, @Valid @RequestBody HousekeepingTaskRequest request) {
        return ApiResponse.success("Housekeeping task updated successfully.", housekeepingTaskService.update(taskId, request, SecurityUtils.getCurrentUser()));
    }
}
