package com.hospease.controller;

import com.hospease.requestdto.RoomRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.RoomResponse;
import com.hospease.service.RoomService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    @GetMapping
    @PreAuthorize("hasAuthority('ROOM_READ')")
    public ApiResponse<List<RoomResponse>> findAll() {
        return ApiResponse.success("Rooms fetched successfully.", roomService.findAll());
    }

    @GetMapping("/{roomId}")
    @PreAuthorize("hasAuthority('ROOM_READ')")
    public ApiResponse<RoomResponse> findById(@PathVariable Long roomId) {
        return ApiResponse.success("Room fetched successfully.", roomService.findById(roomId));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('ROOM_WRITE')")
    public ApiResponse<RoomResponse> create(@Valid @RequestBody RoomRequest request) {
        return ApiResponse.success("Room created successfully.", roomService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{roomId}")
    @PreAuthorize("hasAuthority('ROOM_WRITE')")
    public ApiResponse<RoomResponse> update(@PathVariable Long roomId, @Valid @RequestBody RoomRequest request) {
        return ApiResponse.success("Room updated successfully.", roomService.update(roomId, request, SecurityUtils.getCurrentUser()));
    }
}
