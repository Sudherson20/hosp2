package com.hospease.controller;

import com.hospease.requestdto.ShiftRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.ShiftResponse;
import com.hospease.service.ShiftService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/shifts")
@RequiredArgsConstructor
public class ShiftController {

    private final ShiftService shiftService;

    @GetMapping
    @PreAuthorize("hasAuthority('SHIFT_READ')")
    public ApiResponse<List<ShiftResponse>> findAll() {
        return ApiResponse.success("Shifts fetched successfully.", shiftService.findAllForUser(SecurityUtils.getCurrentUser()));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SHIFT_WRITE')")
    public ApiResponse<ShiftResponse> create(@Valid @RequestBody ShiftRequest request) {
        return ApiResponse.success("Shift created successfully.", shiftService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{shiftId}")
    @PreAuthorize("hasAuthority('SHIFT_WRITE')")
    public ApiResponse<ShiftResponse> update(@PathVariable Long shiftId, @Valid @RequestBody ShiftRequest request) {
        return ApiResponse.success("Shift updated successfully.", shiftService.update(shiftId, request, SecurityUtils.getCurrentUser()));
    }
}
