package com.hospease.controller;

import com.hospease.requestdto.StaffRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.StaffResponse;
import com.hospease.service.StaffService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/staff")
@RequiredArgsConstructor
public class StaffController {

    private final StaffService staffService;

    @GetMapping
    @PreAuthorize("hasAuthority('STAFF_READ')")
    public ApiResponse<List<StaffResponse>> findAll() {
        return ApiResponse.success("Staff fetched successfully.", staffService.findAll());
    }

    @GetMapping("/{staffId}")
    @PreAuthorize("hasAuthority('STAFF_READ')")
    public ApiResponse<StaffResponse> findById(@PathVariable Long staffId) {
        return ApiResponse.success("Staff fetched successfully.", staffService.findById(staffId));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('STAFF_WRITE')")
    public ApiResponse<StaffResponse> create(@Valid @RequestBody StaffRequest request) {
        return ApiResponse.success("Staff created successfully.", staffService.create(request, SecurityUtils.getCurrentUser()));
    }

    @PutMapping("/{staffId}")
    @PreAuthorize("hasAuthority('STAFF_WRITE')")
    public ApiResponse<StaffResponse> update(@PathVariable Long staffId, @Valid @RequestBody StaffRequest request) {
        return ApiResponse.success("Staff updated successfully.", staffService.update(staffId, request, SecurityUtils.getCurrentUser()));
    }
}
