package com.hospease.controller;

import com.hospease.requestdto.ReportRequest;
import com.hospease.responsedto.ApiResponse;
import com.hospease.responsedto.ReportResponse;
import com.hospease.service.ReportService;
import com.hospease.util.SecurityUtils;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @GetMapping
    @PreAuthorize("hasAuthority('REPORT_READ')")
    public ApiResponse<List<ReportResponse>> findAll() {
        return ApiResponse.success("Reports fetched successfully.", reportService.findAll());
    }

    @PostMapping
    @PreAuthorize("hasAuthority('REPORT_WRITE')")
    public ApiResponse<ReportResponse> create(@Valid @RequestBody ReportRequest request) {
        return ApiResponse.success("Report generated successfully.", reportService.create(request, SecurityUtils.getCurrentUser()));
    }
}
