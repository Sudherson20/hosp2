package com.hospease.service;

import com.hospease.entity.HousekeepingTask;
import com.hospease.entity.Room;
import com.hospease.entity.Staff;
import com.hospease.entity.User;
import com.hospease.enums.HousekeepingTaskStatus;
import com.hospease.enums.RoleType;
import com.hospease.enums.RoomStatus;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.HousekeepingTaskRepository;
import com.hospease.requestdto.HousekeepingTaskRequest;
import com.hospease.responsedto.HousekeepingTaskResponse;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class HousekeepingTaskService {

    private final HousekeepingTaskRepository housekeepingTaskRepository;
    private final RoomService roomService;
    private final StaffService staffService;
    private final AuditLogService auditLogService;

    public HousekeepingTask getEntity(Long taskId) {
        return housekeepingTaskRepository.findById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Housekeeping task not found with id: " + taskId));
    }

    public HousekeepingTaskResponse create(HousekeepingTaskRequest request, User actingUser) {
        HousekeepingTask task = new HousekeepingTask();
        apply(task, request);
        if (task.getStatus() == HousekeepingTaskStatus.COMPLETED) {
            task.setCompletedAt(LocalDateTime.now());
            task.getRoom().setStatus(RoomStatus.AVAILABLE);
        } else {
            task.getRoom().setStatus(RoomStatus.CLEANING);
        }
        HousekeepingTask saved = housekeepingTaskRepository.save(task);
        auditLogService.log(actingUser, "HOUSEKEEPING_TASK_CREATED", "HOUSEKEEPING_TASK", saved.getId().toString(), "Housekeeping task created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<HousekeepingTaskResponse> findAllForUser(User currentUser) {
        if (currentUser.getRole() == RoleType.HOUSEKEEPING) {
            Staff staff = staffService.getByUserId(currentUser.getId());
            return housekeepingTaskRepository.findByAssignedToId(staff.getId()).stream().map(this::map).toList();
        }
        return housekeepingTaskRepository.findAll().stream().map(this::map).toList();
    }

    public HousekeepingTaskResponse update(Long taskId, HousekeepingTaskRequest request, User actingUser) {
        HousekeepingTask task = getEntity(taskId);
        apply(task, request);
        if (task.getStatus() == HousekeepingTaskStatus.COMPLETED) {
            task.setCompletedAt(LocalDateTime.now());
            task.getRoom().setStatus(RoomStatus.AVAILABLE);
        } else {
            task.setCompletedAt(null);
            task.getRoom().setStatus(RoomStatus.CLEANING);
        }
        HousekeepingTask saved = housekeepingTaskRepository.save(task);
        auditLogService.log(actingUser, "HOUSEKEEPING_TASK_UPDATED", "HOUSEKEEPING_TASK", saved.getId().toString(), "Housekeeping task updated");
        return map(saved);
    }

    private void apply(HousekeepingTask task, HousekeepingTaskRequest request) {
        Room room = roomService.getEntity(request.roomId());
        Staff staff = staffService.getEntity(request.assignedStaffId());
        task.setRoom(room);
        task.setAssignedTo(staff);
        task.setScheduledAt(request.scheduledAt());
        task.setStatus(request.status());
        task.setNotes(request.notes());
    }

    public HousekeepingTaskResponse map(HousekeepingTask task) {
        return new HousekeepingTaskResponse(
                task.getId(),
                task.getRoom().getId(),
                task.getRoom().getRoomNumber(),
                task.getAssignedTo().getId(),
                task.getAssignedTo().getUser().getName(),
                task.getScheduledAt(),
                task.getCompletedAt(),
                task.getStatus(),
                task.getNotes()
        );
    }
}
