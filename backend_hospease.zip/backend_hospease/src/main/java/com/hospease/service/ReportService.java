package com.hospease.service;

import com.hospease.entity.Report;
import com.hospease.entity.User;
import com.hospease.repository.GuestRepository;
import com.hospease.repository.InvoiceRepository;
import com.hospease.repository.ReportRepository;
import com.hospease.repository.ReservationRepository;
import com.hospease.repository.RoomRepository;
import com.hospease.repository.StaffRepository;
import com.hospease.requestdto.ReportRequest;
import com.hospease.responsedto.ReportResponse;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class ReportService {

    private final ReportRepository reportRepository;
    private final ReservationRepository reservationRepository;
    private final RoomRepository roomRepository;
    private final InvoiceRepository invoiceRepository;
    private final StaffRepository staffRepository;
    private final GuestRepository guestRepository;
    private final AuditLogService auditLogService;

    public ReportResponse create(ReportRequest request, User actingUser) {
        Report report = new Report();
        report.setTitle(request.title());
        report.setScope(request.scope());
        report.setParametersJson(request.parametersJson());
        report.setMetricsJson(buildMetricsJson());
        report.setGeneratedBy(actingUser);
        report.setGeneratedAt(LocalDateTime.now());
        report.setReportUri(request.reportUri());
        Report saved = reportRepository.save(report);
        auditLogService.log(actingUser, "REPORT_GENERATED", "REPORT", saved.getId().toString(), "Report generated");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<ReportResponse> findAll() {
        return reportRepository.findAll().stream().map(this::map).toList();
    }

    private String buildMetricsJson() {
        long reservationCount = reservationRepository.count();
        long roomCount = roomRepository.count();
        long invoiceCount = invoiceRepository.count();
        long staffCount = staffRepository.count();
        long guestCount = guestRepository.count();
        return """
                {
                  "reservations": %d,
                  "rooms": %d,
                  "invoices": %d,
                  "staff": %d,
                  "guests": %d
                }
                """.formatted(reservationCount, roomCount, invoiceCount, staffCount, guestCount).trim();
    }

    public ReportResponse map(Report report) {
        return new ReportResponse(
                report.getId(),
                report.getTitle(),
                report.getScope(),
                report.getParametersJson(),
                report.getMetricsJson(),
                report.getGeneratedBy().getId(),
                report.getGeneratedAt(),
                report.getReportUri()
        );
    }
}
