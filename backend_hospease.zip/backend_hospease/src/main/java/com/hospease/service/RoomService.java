package com.hospease.service;

import com.hospease.entity.Room;
import com.hospease.entity.User;
import com.hospease.exception.BadRequestException;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.RoomRepository;
import com.hospease.requestdto.RoomRequest;
import com.hospease.responsedto.RoomResponse;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class RoomService {

    private final RoomRepository roomRepository;
    private final AuditLogService auditLogService;

    public Room getEntity(Long roomId) {
        return roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + roomId));
    }

    public RoomResponse create(RoomRequest request, User actingUser) {
        roomRepository.findByRoomNumber(request.roomNumber()).ifPresent(existing -> {
            throw new BadRequestException("Room number already exists.");
        });
        Room room = new Room();
        apply(room, request);
        Room saved = roomRepository.save(room);
        auditLogService.log(actingUser, "ROOM_CREATED", "ROOM", saved.getId().toString(), "Room created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<RoomResponse> findAll() {
        return roomRepository.findAll().stream().map(this::map).toList();
    }

    @Transactional(readOnly = true)
    public RoomResponse findById(Long roomId) {
        return map(getEntity(roomId));
    }

    public RoomResponse update(Long roomId, RoomRequest request, User actingUser) {
        Room room = getEntity(roomId);
        roomRepository.findByRoomNumber(request.roomNumber())
                .filter(existing -> !existing.getId().equals(roomId))
                .ifPresent(existing -> {
                    throw new BadRequestException("Another room already uses this room number.");
                });
        apply(room, request);
        Room saved = roomRepository.save(room);
        auditLogService.log(actingUser, "ROOM_UPDATED", "ROOM", saved.getId().toString(), "Room updated");
        return map(saved);
    }

    private void apply(Room room, RoomRequest request) {
        room.setRoomNumber(request.roomNumber());
        room.setRoomType(request.roomType());
        room.setCapacity(request.capacity());
        room.setAmenitiesJson(request.amenitiesJson());
        room.setStatus(request.status());
        room.setRatePerNight(request.ratePerNight());
    }

    public RoomResponse map(Room room) {
        return new RoomResponse(
                room.getId(),
                room.getRoomNumber(),
                room.getRoomType(),
                room.getCapacity(),
                room.getAmenitiesJson(),
                room.getStatus(),
                room.getRatePerNight()
        );
    }
}
