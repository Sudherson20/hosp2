package com.hospease.service;

import com.hospease.entity.User;
import com.hospease.enums.UserStatus;
import com.hospease.exception.BadRequestException;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.UserRepository;
import com.hospease.requestdto.ChangePasswordRequest;
import com.hospease.requestdto.CreateUserRequest;
import com.hospease.requestdto.UpdateUserRequest;
import com.hospease.responsedto.UserResponse;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    public User getEntityById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
    }

    public User getEntityByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }

    public UserResponse create(CreateUserRequest request, User actingUser) {
        validateUniqueFields(request.email(), request.phone(), null);

        User user = new User();
        user.setName(request.name());
        user.setEmail(request.email().toLowerCase());
        user.setPhone(request.phone());
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setRole(request.role());
        user.setStatus(request.status() == null ? UserStatus.ACTIVE : request.status());
        user.setMfaEnabled(request.mfaEnabled());

        User savedUser = userRepository.save(user);
        auditLogService.log(
                actingUser,
                "USER_CREATED",
                "USER",
                savedUser.getId().toString(),
                "Created user with role " + savedUser.getRole()
        );
        return mapToResponse(savedUser);
    }

    public List<UserResponse> findAll() {
        return userRepository.findAll().stream().map(this::mapToResponse).toList();
    }

    public UserResponse findById(Long userId) {
        return mapToResponse(getEntityById(userId));
    }

    public UserResponse update(Long userId, UpdateUserRequest request, User actingUser) {
        User user = getEntityById(userId);
        validateUniqueFields(request.email(), request.phone(), userId);

        user.setName(request.name());
        user.setEmail(request.email().toLowerCase());
        user.setPhone(request.phone());
        if (request.role() != null) {
            user.setRole(request.role());
        }
        if (request.status() != null) {
            user.setStatus(request.status());
        }
        if (request.mfaEnabled() != null) {
            user.setMfaEnabled(request.mfaEnabled());
        }

        User updatedUser = userRepository.save(user);
        auditLogService.log(actingUser, "USER_UPDATED", "USER", updatedUser.getId().toString(), "Updated user profile");
        return mapToResponse(updatedUser);
    }

    public void changePassword(Long userId, ChangePasswordRequest request, User actingUser) {
        User user = getEntityById(userId);
        if (!passwordEncoder.matches(request.currentPassword(), user.getPassword())) {
            throw new BadRequestException("Current password is incorrect.");
        }
        user.setPassword(passwordEncoder.encode(request.newPassword()));
        userRepository.save(user);
        auditLogService.log(actingUser, "PASSWORD_CHANGED", "USER", user.getId().toString(), "Password changed");
    }

    private void validateUniqueFields(String email, String phone, Long userId) {
        userRepository.findByEmail(email.toLowerCase())
                .filter(existing -> !existing.getId().equals(userId))
                .ifPresent(existing -> {
                    throw new BadRequestException("Email already exists.");
                });

        userRepository.findAll().stream()
                .filter(existing -> existing.getPhone().equals(phone))
                .filter(existing -> !existing.getId().equals(userId))
                .findFirst()
                .ifPresent(existing -> {
                    throw new BadRequestException("Phone number already exists.");
                });
    }

    public UserResponse mapToResponse(User user) {
        return new UserResponse(
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getPhone(),
                user.getRole(),
                user.getStatus(),
                user.isMfaEnabled(),
                user.getCreatedAt(),
                user.getUpdatedAt()
        );
    }
}
