package com.hospease.service;

import com.hospease.entity.Task;
import com.hospease.entity.User;
import com.hospease.enums.RoleType;
import com.hospease.enums.TaskStatus;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.TaskRepository;
import com.hospease.requestdto.TaskRequest;
import com.hospease.requestdto.TaskStatusRequest;
import com.hospease.responsedto.TaskResponse;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserService userService;
    private final AuditLogService auditLogService;

    public Task getEntity(Long taskId) {
        return taskRepository.findById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found with id: " + taskId));
    }

    public TaskResponse create(TaskRequest request, User actingUser) {
        Task task = new Task();
        apply(task, request);
        Task saved = taskRepository.save(task);
        auditLogService.log(actingUser, "TASK_CREATED", "TASK", saved.getId().toString(), "Task created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<TaskResponse> findAllForUser(User currentUser) {
        if (currentUser.getRole() == RoleType.ADMIN || currentUser.getRole() == RoleType.MANAGER) {
            return taskRepository.findAll().stream().map(this::map).toList();
        }
        return taskRepository.findByAssignedToId(currentUser.getId()).stream().map(this::map).toList();
    }

    public TaskResponse update(Long taskId, TaskRequest request, User actingUser) {
        Task task = getEntity(taskId);
        apply(task, request);
        Task saved = taskRepository.save(task);
        auditLogService.log(actingUser, "TASK_UPDATED", "TASK", saved.getId().toString(), "Task updated");
        return map(saved);
    }

    public TaskResponse updateStatus(Long taskId, TaskStatusRequest request, User actingUser) {
        Task task = getEntity(taskId);
        task.setStatus(request.status());
        if (request.status() == TaskStatus.COMPLETED) {
            task.setCompletedAt(LocalDateTime.now());
        } else {
            task.setCompletedAt(null);
        }
        Task saved = taskRepository.save(task);
        auditLogService.log(actingUser, "TASK_STATUS_UPDATED", "TASK", saved.getId().toString(), "Task status updated");
        return map(saved);
    }

    private void apply(Task task, TaskRequest request) {
        task.setAssignedTo(userService.getEntityById(request.assignedToUserId()));
        task.setRelatedEntityId(request.relatedEntityId());
        task.setRelatedEntityType(request.relatedEntityType());
        task.setDescription(request.description());
        task.setDueDate(request.dueDate());
        task.setPriority(request.priority());
        task.setStatus(request.status());
        if (request.status() == TaskStatus.COMPLETED) {
            task.setCompletedAt(LocalDateTime.now());
        } else {
            task.setCompletedAt(null);
        }
    }

    public TaskResponse map(Task task) {
        return new TaskResponse(
                task.getId(),
                task.getAssignedTo().getId(),
                task.getAssignedTo().getName(),
                task.getRelatedEntityId(),
                task.getRelatedEntityType(),
                task.getDescription(),
                task.getDueDate(),
                task.getPriority(),
                task.getCompletedAt(),
                task.getStatus()
        );
    }
}
