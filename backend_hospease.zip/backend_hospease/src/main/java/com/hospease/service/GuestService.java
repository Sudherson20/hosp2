package com.hospease.service;

import com.hospease.entity.Guest;
import com.hospease.entity.User;
import com.hospease.exception.BadRequestException;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.GuestRepository;
import com.hospease.requestdto.GuestRequest;
import com.hospease.responsedto.GuestResponse;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class GuestService {

    private final GuestRepository guestRepository;
    private final UserService userService;
    private final AuditLogService auditLogService;

    public Guest getEntity(Long guestId) {
        return guestRepository.findById(guestId)
                .orElseThrow(() -> new ResourceNotFoundException("Guest not found with id: " + guestId));
    }

    public Guest getByUserId(Long userId) {
        return guestRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Guest profile not found for user id: " + userId));
    }

    public GuestResponse create(GuestRequest request, User actingUser) {
        User user = userService.getEntityById(request.userId());
        guestRepository.findByUserId(user.getId()).ifPresent(existing -> {
            throw new BadRequestException("Guest profile already exists for this user.");
        });

        Guest guest = new Guest();
        apply(guest, request, user);
        Guest saved = guestRepository.save(guest);
        auditLogService.log(actingUser, "GUEST_CREATED", "GUEST", saved.getId().toString(), "Guest profile created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<GuestResponse> findAll() {
        return guestRepository.findAll().stream().map(this::map).toList();
    }

    @Transactional(readOnly = true)
    public GuestResponse findById(Long guestId) {
        return map(getEntity(guestId));
    }

    @Transactional(readOnly = true)
    public GuestResponse findByCurrentUser(Long userId) {
        return map(getByUserId(userId));
    }

    public GuestResponse update(Long guestId, GuestRequest request, User actingUser) {
        Guest guest = getEntity(guestId);
        User user = userService.getEntityById(request.userId());
        guestRepository.findByUserId(user.getId())
                .filter(existing -> !existing.getId().equals(guestId))
                .ifPresent(existing -> {
                    throw new BadRequestException("Another guest profile already uses this user.");
                });
        apply(guest, request, user);
        Guest saved = guestRepository.save(guest);
        auditLogService.log(actingUser, "GUEST_UPDATED", "GUEST", saved.getId().toString(), "Guest profile updated");
        return map(saved);
    }

    private void apply(Guest guest, GuestRequest request, User user) {
        guest.setUser(user);
        guest.setFullName(request.fullName());
        guest.setDateOfBirth(request.dateOfBirth());
        guest.setContactInfoJson(request.contactInfoJson());
        guest.setAddressJson(request.addressJson());
        guest.setLoyaltyTier(request.loyaltyTier());
        guest.setGuestStatus(request.guestStatus());
    }

    public GuestResponse map(Guest guest) {
        return new GuestResponse(
                guest.getId(),
                guest.getUser().getId(),
                guest.getFullName(),
                guest.getDateOfBirth(),
                guest.getContactInfoJson(),
                guest.getAddressJson(),
                guest.getLoyaltyTier(),
                guest.getGuestStatus()
        );
    }
}
