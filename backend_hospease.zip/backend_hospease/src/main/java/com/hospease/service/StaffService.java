package com.hospease.service;

import com.hospease.entity.Staff;
import com.hospease.entity.User;
import com.hospease.exception.BadRequestException;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.StaffRepository;
import com.hospease.requestdto.StaffRequest;
import com.hospease.responsedto.StaffResponse;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class StaffService {

    private final StaffRepository staffRepository;
    private final UserService userService;
    private final AuditLogService auditLogService;

    public Staff getEntity(Long staffId) {
        return staffRepository.findById(staffId)
                .orElseThrow(() -> new ResourceNotFoundException("Staff not found with id: " + staffId));
    }

    public Staff getByUserId(Long userId) {
        return staffRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Staff profile not found for user id: " + userId));
    }

    public StaffResponse create(StaffRequest request, User actingUser) {
        User user = userService.getEntityById(request.userId());
        staffRepository.findByUserId(user.getId()).ifPresent(existing -> {
            throw new BadRequestException("Staff profile already exists for this user.");
        });
        Staff staff = new Staff();
        apply(staff, request, user);
        Staff saved = staffRepository.save(staff);
        auditLogService.log(actingUser, "STAFF_CREATED", "STAFF", saved.getId().toString(), "Staff profile created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<StaffResponse> findAll() {
        return staffRepository.findAll().stream().map(this::map).toList();
    }

    @Transactional(readOnly = true)
    public StaffResponse findById(Long staffId) {
        return map(getEntity(staffId));
    }

    public StaffResponse update(Long staffId, StaffRequest request, User actingUser) {
        Staff staff = getEntity(staffId);
        User user = userService.getEntityById(request.userId());
        staffRepository.findByUserId(user.getId())
                .filter(existing -> !existing.getId().equals(staffId))
                .ifPresent(existing -> {
                    throw new BadRequestException("Another staff profile already uses this user.");
                });
        apply(staff, request, user);
        Staff saved = staffRepository.save(staff);
        auditLogService.log(actingUser, "STAFF_UPDATED", "STAFF", saved.getId().toString(), "Staff profile updated");
        return map(saved);
    }

    private void apply(Staff staff, StaffRequest request, User user) {
        staff.setUser(user);
        staff.setRole(request.role());
        staff.setDepartment(request.department());
        staff.setContactInfoJson(request.contactInfoJson());
        staff.setStaffStatus(request.staffStatus());
    }

    public StaffResponse map(Staff staff) {
        return new StaffResponse(
                staff.getId(),
                staff.getUser().getId(),
                staff.getRole(),
                staff.getDepartment(),
                staff.getContactInfoJson(),
                staff.getStaffStatus()
        );
    }
}
