package com.hospease.service;

import com.hospease.entity.Notification;
import com.hospease.entity.User;
import com.hospease.enums.NotificationStatus;
import com.hospease.enums.RoleType;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.NotificationRepository;
import com.hospease.requestdto.NotificationRequest;
import com.hospease.responsedto.NotificationResponse;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserService userService;
    private final AuditLogService auditLogService;

    public Notification getEntity(Long notificationId) {
        return notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with id: " + notificationId));
    }

    public NotificationResponse create(NotificationRequest request, User actingUser) {
        Notification notification = new Notification();
        apply(notification, request);
        Notification saved = notificationRepository.save(notification);
        auditLogService.log(actingUser, "NOTIFICATION_CREATED", "NOTIFICATION", saved.getId().toString(), "Notification created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> findAllForUser(User currentUser) {
        if (currentUser.getRole() == RoleType.ADMIN || currentUser.getRole() == RoleType.MANAGER) {
            return notificationRepository.findAll().stream().map(this::map).toList();
        }
        return notificationRepository.findByUserId(currentUser.getId()).stream().map(this::map).toList();
    }

    public NotificationResponse markAsRead(Long notificationId, User currentUser) {
        Notification notification = getEntity(notificationId);
        if (!notification.getUser().getId().equals(currentUser.getId()) && currentUser.getRole() != RoleType.ADMIN) {
            throw new ResourceNotFoundException("Notification not found for current user.");
        }
        notification.setStatus(NotificationStatus.READ);
        notification.setReadAt(LocalDateTime.now());
        Notification saved = notificationRepository.save(notification);
        return map(saved);
    }

    private void apply(Notification notification, NotificationRequest request) {
        notification.setUser(userService.getEntityById(request.userId()));
        notification.setEntityId(request.entityId());
        notification.setMessage(request.message());
        notification.setCategory(request.category());
        notification.setSeverity(request.severity());
        notification.setStatus(request.status());
        if (request.status() == NotificationStatus.READ) {
            notification.setReadAt(LocalDateTime.now());
        } else {
            notification.setReadAt(null);
        }
    }

    public NotificationResponse map(Notification notification) {
        return new NotificationResponse(
                notification.getId(),
                notification.getUser().getId(),
                notification.getEntityId(),
                notification.getMessage(),
                notification.getCategory(),
                notification.getSeverity(),
                notification.getReadAt(),
                notification.getStatus()
        );
    }
}
