package com.hospease.service;

import com.hospease.entity.Guest;
import com.hospease.entity.Invoice;
import com.hospease.entity.Reservation;
import com.hospease.entity.User;
import com.hospease.enums.RoleType;
import com.hospease.exception.BadRequestException;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.InvoiceRepository;
import com.hospease.requestdto.InvoiceRequest;
import com.hospease.responsedto.InvoiceResponse;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final GuestService guestService;
    private final ReservationService reservationService;
    private final AuditLogService auditLogService;

    public Invoice getEntity(Long invoiceId) {
        return invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found with id: " + invoiceId));
    }

    public InvoiceResponse create(InvoiceRequest request, User actingUser) {
        Invoice invoice = new Invoice();
        apply(invoice, request);
        invoice.setIssuedAt(LocalDateTime.now());
        Invoice saved = invoiceRepository.save(invoice);
        auditLogService.log(actingUser, "INVOICE_CREATED", "INVOICE", saved.getId().toString(), "Invoice created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<InvoiceResponse> findAllForUser(User currentUser) {
        if (currentUser.getRole() == RoleType.GUEST) {
            Guest guest = guestService.getByUserId(currentUser.getId());
            return invoiceRepository.findByGuestId(guest.getId()).stream().map(this::map).toList();
        }
        return invoiceRepository.findAll().stream().map(this::map).toList();
    }

    @Transactional(readOnly = true)
    public InvoiceResponse findById(Long invoiceId, User currentUser) {
        Invoice invoice = getEntity(invoiceId);
        if (currentUser.getRole() == RoleType.GUEST && !invoice.getGuest().getUser().getId().equals(currentUser.getId())) {
            throw new BadRequestException("Guests can only view their own invoices.");
        }
        return map(invoice);
    }

    public InvoiceResponse update(Long invoiceId, InvoiceRequest request, User actingUser) {
        Invoice invoice = getEntity(invoiceId);
        apply(invoice, request);
        Invoice saved = invoiceRepository.save(invoice);
        auditLogService.log(actingUser, "INVOICE_UPDATED", "INVOICE", saved.getId().toString(), "Invoice updated");
        return map(saved);
    }

    private void apply(Invoice invoice, InvoiceRequest request) {
        Guest guest = guestService.getEntity(request.guestId());
        invoice.setGuest(guest);
        Reservation reservation = request.reservationId() != null ? reservationService.getEntity(request.reservationId()) : null;
        invoice.setReservation(reservation);
        invoice.setLineItemsJson(request.lineItemsJson());
        invoice.setTotalAmount(request.totalAmount());
        invoice.setCurrency(request.currency());
        invoice.setDueDate(request.dueDate());
        invoice.setStatus(request.status());
        invoice.setInvoiceUri(request.invoiceUri());
        invoice.setReconciliationNotes(request.reconciliationNotes());
    }

    public InvoiceResponse map(Invoice invoice) {
        return new InvoiceResponse(
                invoice.getId(),
                invoice.getGuest().getId(),
                invoice.getGuest().getFullName(),
                invoice.getReservation() != null ? invoice.getReservation().getId() : null,
                invoice.getLineItemsJson(),
                invoice.getTotalAmount(),
                invoice.getCurrency(),
                invoice.getIssuedAt(),
                invoice.getDueDate(),
                invoice.getStatus(),
                invoice.getInvoiceUri(),
                invoice.getReconciliationNotes()
        );
    }
}
