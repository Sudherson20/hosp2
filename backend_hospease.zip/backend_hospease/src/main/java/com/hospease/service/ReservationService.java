package com.hospease.service;

import com.hospease.entity.Guest;
import com.hospease.entity.Reservation;
import com.hospease.entity.Room;
import com.hospease.entity.User;
import com.hospease.enums.ReservationStatus;
import com.hospease.enums.RoleType;
import com.hospease.enums.RoomStatus;
import com.hospease.exception.BadRequestException;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.ReservationRepository;
import com.hospease.requestdto.ReservationRequest;
import com.hospease.requestdto.ReservationStatusRequest;
import com.hospease.responsedto.ReservationResponse;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final GuestService guestService;
    private final RoomService roomService;
    private final AuditLogService auditLogService;

    public Reservation getEntity(Long reservationId) {
        return reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found with id: " + reservationId));
    }

    public ReservationResponse create(ReservationRequest request, User actingUser) {
        validateDates(request.checkInDate(), request.checkOutDate());
        Guest guest = guestService.getEntity(request.guestId());
        Room room = roomService.getEntity(request.roomId());
        validateRoomAvailability(room.getId(), request.checkInDate(), request.checkOutDate(), null);

        Reservation reservation = new Reservation();
        reservation.setGuest(guest);
        reservation.setRoom(room);
        reservation.setCheckInDate(request.checkInDate());
        reservation.setCheckOutDate(request.checkOutDate());
        reservation.setStatus(ReservationStatus.CONFIRMED);
        Reservation saved = reservationRepository.save(reservation);

        auditLogService.log(actingUser, "RESERVATION_CREATED", "RESERVATION", saved.getId().toString(), "Reservation created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<ReservationResponse> findAllForUser(User currentUser) {
        if (currentUser.getRole() == RoleType.GUEST) {
            Guest guest = guestService.getByUserId(currentUser.getId());
            return reservationRepository.findByGuestId(guest.getId()).stream().map(this::map).toList();
        }
        return reservationRepository.findAll().stream().map(this::map).toList();
    }

    @Transactional(readOnly = true)
    public ReservationResponse findById(Long reservationId, User currentUser) {
        Reservation reservation = getEntity(reservationId);
        if (currentUser.getRole() == RoleType.GUEST && !reservation.getGuest().getUser().getId().equals(currentUser.getId())) {
            throw new BadRequestException("Guests can only view their own reservations.");
        }
        return map(reservation);
    }

    public ReservationResponse update(Long reservationId, ReservationRequest request, User actingUser) {
        Reservation reservation = getEntity(reservationId);
        validateDates(request.checkInDate(), request.checkOutDate());
        Guest guest = guestService.getEntity(request.guestId());
        Room room = roomService.getEntity(request.roomId());
        validateRoomAvailability(room.getId(), request.checkInDate(), request.checkOutDate(), reservationId);

        reservation.setGuest(guest);
        reservation.setRoom(room);
        reservation.setCheckInDate(request.checkInDate());
        reservation.setCheckOutDate(request.checkOutDate());
        Reservation saved = reservationRepository.save(reservation);
        auditLogService.log(actingUser, "RESERVATION_UPDATED", "RESERVATION", saved.getId().toString(), "Reservation updated");
        return map(saved);
    }

    public ReservationResponse updateStatus(Long reservationId, ReservationStatusRequest request, User actingUser) {
        Reservation reservation = getEntity(reservationId);
        reservation.setStatus(request.status());
        updateRoomStatusForReservation(reservation);
        Reservation saved = reservationRepository.save(reservation);
        auditLogService.log(actingUser, "RESERVATION_STATUS_UPDATED", "RESERVATION", saved.getId().toString(), "Status changed to " + request.status());
        return map(saved);
    }

    private void validateDates(java.time.LocalDate checkIn, java.time.LocalDate checkOut) {
        if (!checkOut.isAfter(checkIn)) {
            throw new BadRequestException("Check-out date must be after check-in date.");
        }
    }

    private void validateRoomAvailability(Long roomId, java.time.LocalDate checkIn, java.time.LocalDate checkOut, Long reservationId) {
        if (reservationRepository.hasOverlappingReservation(roomId, checkIn, checkOut, reservationId)) {
            throw new BadRequestException("Room is not available for the selected dates.");
        }
    }

    private void updateRoomStatusForReservation(Reservation reservation) {
        Room room = reservation.getRoom();
        if (reservation.getStatus() == ReservationStatus.CHECKED_IN) {
            room.setStatus(RoomStatus.OCCUPIED);
        } else if (reservation.getStatus() == ReservationStatus.CHECKED_OUT || reservation.getStatus() == ReservationStatus.CANCELLED) {
            room.setStatus(RoomStatus.AVAILABLE);
        }
    }

    public ReservationResponse map(Reservation reservation) {
        return new ReservationResponse(
                reservation.getId(),
                reservation.getGuest().getId(),
                reservation.getGuest().getFullName(),
                reservation.getRoom().getId(),
                reservation.getRoom().getRoomNumber(),
                reservation.getCheckInDate(),
                reservation.getCheckOutDate(),
                reservation.getStatus()
        );
    }
}
