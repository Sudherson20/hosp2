package com.hospease.service;

import com.hospease.entity.Shift;
import com.hospease.entity.Staff;
import com.hospease.entity.User;
import com.hospease.enums.RoleType;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.ShiftRepository;
import com.hospease.requestdto.ShiftRequest;
import com.hospease.responsedto.ShiftResponse;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class ShiftService {

    private final ShiftRepository shiftRepository;
    private final StaffService staffService;
    private final AuditLogService auditLogService;

    public Shift getEntity(Long shiftId) {
        return shiftRepository.findById(shiftId)
                .orElseThrow(() -> new ResourceNotFoundException("Shift not found with id: " + shiftId));
    }

    public ShiftResponse create(ShiftRequest request, User actingUser) {
        Shift shift = new Shift();
        apply(shift, request, actingUser);
        Shift saved = shiftRepository.save(shift);
        auditLogService.log(actingUser, "SHIFT_CREATED", "SHIFT", saved.getId().toString(), "Shift created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<ShiftResponse> findAllForUser(User currentUser) {
        if (currentUser.getRole() != RoleType.MANAGER && currentUser.getRole() != RoleType.ADMIN) {
            Staff staff = staffService.getByUserId(currentUser.getId());
            return shiftRepository.findByStaffId(staff.getId()).stream().map(this::map).toList();
        }
        return shiftRepository.findAll().stream().map(this::map).toList();
    }

    public ShiftResponse update(Long shiftId, ShiftRequest request, User actingUser) {
        Shift shift = getEntity(shiftId);
        apply(shift, request, actingUser);
        Shift saved = shiftRepository.save(shift);
        auditLogService.log(actingUser, "SHIFT_UPDATED", "SHIFT", saved.getId().toString(), "Shift updated");
        return map(saved);
    }

    private void apply(Shift shift, ShiftRequest request, User actingUser) {
        Staff staff = staffService.getEntity(request.staffId());
        shift.setStaff(staff);
        shift.setStartAt(request.startAt());
        shift.setEndAt(request.endAt());
        shift.setAssignedBy(actingUser);
        shift.setStatus(request.status());
    }

    public ShiftResponse map(Shift shift) {
        return new ShiftResponse(
                shift.getId(),
                shift.getStaff().getId(),
                shift.getStaff().getUser().getName(),
                shift.getStartAt(),
                shift.getEndAt(),
                shift.getAssignedBy().getId(),
                shift.getStatus()
        );
    }
}
