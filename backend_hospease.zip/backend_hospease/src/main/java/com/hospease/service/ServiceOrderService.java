package com.hospease.service;

import com.hospease.entity.Guest;
import com.hospease.entity.Room;
import com.hospease.entity.ServiceOrder;
import com.hospease.entity.User;
import com.hospease.enums.RoleType;
import com.hospease.enums.ServiceOrderStatus;
import com.hospease.exception.BadRequestException;
import com.hospease.exception.ResourceNotFoundException;
import com.hospease.repository.ServiceOrderRepository;
import com.hospease.requestdto.ServiceOrderRequest;
import com.hospease.requestdto.ServiceOrderStatusRequest;
import com.hospease.responsedto.ServiceOrderResponse;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class ServiceOrderService {

    private final ServiceOrderRepository serviceOrderRepository;
    private final GuestService guestService;
    private final RoomService roomService;
    private final AuditLogService auditLogService;

    public ServiceOrder getEntity(Long orderId) {
        return serviceOrderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Service order not found with id: " + orderId));
    }

    public ServiceOrderResponse create(ServiceOrderRequest request, User actingUser) {
        Guest guest = guestService.getEntity(request.guestId());
        Room room = roomService.getEntity(request.roomId());
        ServiceOrder order = new ServiceOrder();
        order.setGuest(guest);
        order.setRoom(room);
        order.setServiceType(request.serviceType());
        order.setDetailsJson(request.detailsJson());
        order.setAmount(request.amount());
        order.setOrderedAt(LocalDateTime.now());
        order.setStatus(ServiceOrderStatus.REQUESTED);
        ServiceOrder saved = serviceOrderRepository.save(order);
        auditLogService.log(actingUser, "SERVICE_ORDER_CREATED", "SERVICE_ORDER", saved.getId().toString(), "Service order created");
        return map(saved);
    }

    @Transactional(readOnly = true)
    public List<ServiceOrderResponse> findAllForUser(User currentUser) {
        if (currentUser.getRole() == RoleType.GUEST) {
            Guest guest = guestService.getByUserId(currentUser.getId());
            return serviceOrderRepository.findByGuestId(guest.getId()).stream().map(this::map).toList();
        }
        return serviceOrderRepository.findAll().stream().map(this::map).toList();
    }

    public ServiceOrderResponse update(Long orderId, ServiceOrderRequest request, User actingUser) {
        ServiceOrder order = getEntity(orderId);
        Guest guest = guestService.getEntity(request.guestId());
        Room room = roomService.getEntity(request.roomId());
        order.setGuest(guest);
        order.setRoom(room);
        order.setServiceType(request.serviceType());
        order.setDetailsJson(request.detailsJson());
        order.setAmount(request.amount());
        ServiceOrder saved = serviceOrderRepository.save(order);
        auditLogService.log(actingUser, "SERVICE_ORDER_UPDATED", "SERVICE_ORDER", saved.getId().toString(), "Service order updated");
        return map(saved);
    }

    public ServiceOrderResponse updateStatus(Long orderId, ServiceOrderStatusRequest request, User actingUser) {
        ServiceOrder order = getEntity(orderId);
        order.setStatus(request.status());
        if (request.status() == ServiceOrderStatus.FULFILLED) {
            order.setFulfilledAt(LocalDateTime.now());
        } else if (request.status() == ServiceOrderStatus.CANCELLED || request.status() == ServiceOrderStatus.IN_PROGRESS) {
            order.setFulfilledAt(null);
        }
        ServiceOrder saved = serviceOrderRepository.save(order);
        auditLogService.log(actingUser, "SERVICE_ORDER_STATUS_UPDATED", "SERVICE_ORDER", saved.getId().toString(), "Status changed to " + request.status());
        return map(saved);
    }

    @Transactional(readOnly = true)
    public ServiceOrderResponse findById(Long orderId, User currentUser) {
        ServiceOrder order = getEntity(orderId);
        if (currentUser.getRole() == RoleType.GUEST && !order.getGuest().getUser().getId().equals(currentUser.getId())) {
            throw new BadRequestException("Guests can only view their own service orders.");
        }
        return map(order);
    }

    public ServiceOrderResponse map(ServiceOrder order) {
        return new ServiceOrderResponse(
                order.getId(),
                order.getGuest().getId(),
                order.getGuest().getFullName(),
                order.getRoom().getId(),
                order.getRoom().getRoomNumber(),
                order.getServiceType(),
                order.getDetailsJson(),
                order.getAmount(),
                order.getOrderedAt(),
                order.getFulfilledAt(),
                order.getStatus()
        );
    }
}
