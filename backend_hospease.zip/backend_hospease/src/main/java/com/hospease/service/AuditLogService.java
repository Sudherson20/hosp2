package com.hospease.service;

import com.hospease.entity.AuditLog;
import com.hospease.entity.User;
import com.hospease.repository.AuditLogRepository;
import com.hospease.responsedto.AuditLogResponse;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public void log(User user, String action, String resourceType, String resourceId, String details) {
        AuditLog auditLog = new AuditLog();
        auditLog.setUser(user);
        auditLog.setAction(action);
        auditLog.setResourceType(resourceType);
        auditLog.setResourceId(resourceId);
        auditLog.setDetails(details);
        auditLogRepository.save(auditLog);
    }

    public List<AuditLogResponse> findAll() {
        return auditLogRepository.findAll().stream()
                .map(log -> new AuditLogResponse(
                        log.getId(),
                        log.getUser() != null ? log.getUser().getId() : null,
                        log.getUser() != null ? log.getUser().getEmail() : null,
                        log.getAction(),
                        log.getResourceType(),
                        log.getResourceId(),
                        log.getDetails(),
                        log.getCreatedAt()
                ))
                .toList();
    }
}
