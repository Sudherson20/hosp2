package com.hospease.service;

import com.hospease.entity.Guest;
import com.hospease.entity.User;
import com.hospease.enums.RoleType;
import com.hospease.enums.UserStatus;
import com.hospease.exception.BadRequestException;
import com.hospease.repository.GuestRepository;
import com.hospease.repository.UserRepository;
import com.hospease.requestdto.LoginRequest;
import com.hospease.requestdto.RegisterGuestRequest;
import com.hospease.responsedto.AuthResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.hospease.security.CustomUserDetails;
import com.hospease.security.JwtService;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final AuditLogService auditLogService;
    private final UserRepository userRepository;
    private final GuestRepository guestRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.email(), request.password())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        User user = userDetails.getUser();

        auditLogService.log(user, "LOGIN_SUCCESS", "AUTH", user.getId().toString(), "User logged in");

        return new AuthResponse(
                jwtService.generateAccessToken(userDetails),
                jwtService.generateRefreshToken(userDetails),
                "Bearer",
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getRole()
        );
    }

    public AuthResponse registerGuest(RegisterGuestRequest request) {
        if (userRepository.existsByEmail(request.email().toLowerCase())) {
            throw new BadRequestException("Email already exists.");
        }
        if (userRepository.existsByPhone(request.phone())) {
            throw new BadRequestException("Phone number already exists.");
        }

        User user = new User();
        user.setName(request.name());
        user.setEmail(request.email().toLowerCase());
        user.setPhone(request.phone());
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setRole(RoleType.GUEST);
        user.setStatus(UserStatus.ACTIVE);
        user.setMfaEnabled(false);
        User savedUser = userRepository.save(user);

        Guest guest = new Guest();
        guest.setUser(savedUser);
        guest.setFullName(request.name());
        guest.setDateOfBirth(request.dateOfBirth());
        guest.setContactInfoJson(
                request.contactInfoJson() != null && !request.contactInfoJson().isBlank()
                        ? request.contactInfoJson()
                        : "{\"email\":\"" + request.email().toLowerCase() + "\",\"phone\":\"" + request.phone() + "\"}"
        );
        guest.setAddressJson(request.addressJson());
        guest.setLoyaltyTier(request.loyaltyTier() != null ? request.loyaltyTier() : "Bronze");
        guest.setGuestStatus("ACTIVE");
        guestRepository.save(guest);

        CustomUserDetails userDetails = new CustomUserDetails(savedUser);
        auditLogService.log(savedUser, "GUEST_REGISTERED", "USER", savedUser.getId().toString(), "Guest self-registered");

        return new AuthResponse(
                jwtService.generateAccessToken(userDetails),
                jwtService.generateRefreshToken(userDetails),
                "Bearer",
                savedUser.getId(),
                savedUser.getName(),
                savedUser.getEmail(),
                savedUser.getRole()
        );
    }
}
