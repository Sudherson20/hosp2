package com.hospease.util;

import com.hospease.entity.User;
import com.hospease.exception.BadRequestException;
import com.hospease.enums.RoleType;
import com.hospease.security.CustomUserDetails;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public final class SecurityUtils {

    private SecurityUtils() {
    }

    public static User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof CustomUserDetails details)) {
            throw new BadRequestException("Current user is not available.");
        }
        return details.getUser();
    }

    public static boolean hasRole(RoleType roleType) {
        return getCurrentUser().getRole() == roleType;
    }
}
