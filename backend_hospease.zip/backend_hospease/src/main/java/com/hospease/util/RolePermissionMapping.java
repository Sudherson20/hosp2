package com.hospease.util;

import com.hospease.enums.PermissionCode;
import com.hospease.enums.RoleType;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

public final class RolePermissionMapping {

    private static final Map<RoleType, Set<PermissionCode>> PERMISSIONS = new EnumMap<>(RoleType.class);

    static {
        PERMISSIONS.put(RoleType.GUEST, EnumSet.of(
                PermissionCode.PROFILE_SELF_READ,
                PermissionCode.PROFILE_SELF_WRITE,
                PermissionCode.ROOM_READ,
                PermissionCode.RESERVATION_READ,
                PermissionCode.RESERVATION_WRITE,
                PermissionCode.SERVICE_ORDER_READ,
                PermissionCode.SERVICE_ORDER_WRITE,
                PermissionCode.INVOICE_READ,
                PermissionCode.NOTIFICATION_READ,
                PermissionCode.TASK_READ
        ));

        PERMISSIONS.put(RoleType.FRONT_DESK, EnumSet.of(
                PermissionCode.GUEST_READ,
                PermissionCode.GUEST_WRITE,
                PermissionCode.RESERVATION_READ,
                PermissionCode.RESERVATION_WRITE,
                PermissionCode.RESERVATION_CHECKIN,
                PermissionCode.ROOM_READ,
                PermissionCode.INVOICE_READ,
                PermissionCode.NOTIFICATION_READ,
                PermissionCode.NOTIFICATION_WRITE,
                PermissionCode.TASK_READ,
                PermissionCode.TASK_WRITE
        ));

        PERMISSIONS.put(RoleType.HOUSEKEEPING, EnumSet.of(
                PermissionCode.ROOM_READ,
                PermissionCode.ROOM_WRITE,
                PermissionCode.HOUSEKEEPING_READ,
                PermissionCode.HOUSEKEEPING_WRITE,
                PermissionCode.TASK_READ,
                PermissionCode.TASK_WRITE,
                PermissionCode.NOTIFICATION_READ
        ));

        PERMISSIONS.put(RoleType.SERVICE_STAFF, EnumSet.of(
                PermissionCode.SERVICE_ORDER_READ,
                PermissionCode.SERVICE_ORDER_WRITE,
                PermissionCode.ROOM_READ,
                PermissionCode.NOTIFICATION_READ,
                PermissionCode.TASK_READ
        ));

        PERMISSIONS.put(RoleType.FINANCE, EnumSet.of(
                PermissionCode.INVOICE_READ,
                PermissionCode.INVOICE_WRITE,
                PermissionCode.PAYMENT_TRACKING,
                PermissionCode.REPORT_READ,
                PermissionCode.REPORT_WRITE,
                PermissionCode.NOTIFICATION_READ
        ));

        PERMISSIONS.put(RoleType.MANAGER, EnumSet.of(
                PermissionCode.GUEST_READ,
                PermissionCode.RESERVATION_READ,
                PermissionCode.ROOM_READ,
                PermissionCode.HOUSEKEEPING_READ,
                PermissionCode.SERVICE_ORDER_READ,
                PermissionCode.INVOICE_READ,
                PermissionCode.STAFF_READ,
                PermissionCode.STAFF_WRITE,
                PermissionCode.SHIFT_READ,
                PermissionCode.SHIFT_WRITE,
                PermissionCode.REPORT_READ,
                PermissionCode.REPORT_WRITE,
                PermissionCode.TASK_READ,
                PermissionCode.TASK_WRITE,
                PermissionCode.NOTIFICATION_READ,
                PermissionCode.NOTIFICATION_WRITE
        ));

        PERMISSIONS.put(RoleType.ADMIN, EnumSet.allOf(PermissionCode.class));

        PERMISSIONS.put(RoleType.AUDITOR, EnumSet.of(
                PermissionCode.REPORT_READ,
                PermissionCode.AUDIT_LOG_READ,
                PermissionCode.INVOICE_READ,
                PermissionCode.GUEST_READ,
                PermissionCode.RESERVATION_READ
        ));
    }

    private RolePermissionMapping() {
    }

    public static Set<PermissionCode> getPermissions(RoleType roleType) {
        return PERMISSIONS.getOrDefault(roleType, EnumSet.noneOf(PermissionCode.class));
    }
}
