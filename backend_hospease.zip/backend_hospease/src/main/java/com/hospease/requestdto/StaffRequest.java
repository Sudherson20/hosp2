package com.hospease.requestdto;

import com.hospease.enums.RoleType;
import com.hospease.enums.StaffDepartment;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record StaffRequest(
        @NotNull Long userId,
        @NotNull RoleType role,
        @NotNull StaffDepartment department,
        String contactInfoJson,
        @NotBlank String staffStatus
) {
}
