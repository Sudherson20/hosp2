package com.hospease.requestdto;

import com.hospease.enums.InvoiceStatus;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

public record InvoiceRequest(
        @NotNull Long guestId,
        Long reservationId,
        @NotBlank String lineItemsJson,
        @NotNull @DecimalMin("0.0") BigDecimal totalAmount,
        @NotBlank String currency,
        @NotNull LocalDate dueDate,
        @NotNull InvoiceStatus status,
        String invoiceUri,
        String reconciliationNotes
) {
}
