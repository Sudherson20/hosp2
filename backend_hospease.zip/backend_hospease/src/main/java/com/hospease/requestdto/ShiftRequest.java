package com.hospease.requestdto;

import com.hospease.enums.ShiftStatus;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

public record ShiftRequest(
        @NotNull Long staffId,
        @NotNull LocalDateTime startAt,
        @NotNull LocalDateTime endAt,
        @NotNull ShiftStatus status
) {
}
