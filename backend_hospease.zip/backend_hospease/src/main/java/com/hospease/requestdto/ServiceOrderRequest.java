package com.hospease.requestdto;

import com.hospease.enums.ServiceType;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public record ServiceOrderRequest(
        @NotNull Long guestId,
        @NotNull Long roomId,
        @NotNull ServiceType serviceType,
        String detailsJson,
        @NotNull @DecimalMin("0.0") BigDecimal amount
) {
}
