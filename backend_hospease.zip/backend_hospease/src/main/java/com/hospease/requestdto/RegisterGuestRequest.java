package com.hospease.requestdto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

public record RegisterGuestRequest(
        @NotBlank @Size(max = 120) String name,
        @NotBlank @Email String email,
        @NotBlank @Pattern(regexp = "^[0-9+\\-]{10,20}$", message = "Phone number must be 10 to 20 digits") String phone,
        @NotBlank @Size(min = 8, max = 100) String password,
        LocalDate dateOfBirth,
        String contactInfoJson,
        String addressJson,
        String loyaltyTier
) {
}
