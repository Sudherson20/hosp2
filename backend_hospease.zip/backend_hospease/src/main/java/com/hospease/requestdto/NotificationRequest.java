package com.hospease.requestdto;

import com.hospease.enums.NotificationCategory;
import com.hospease.enums.NotificationSeverity;
import com.hospease.enums.NotificationStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record NotificationRequest(
        @NotNull Long userId,
        String entityId,
        @NotBlank String message,
        @NotNull NotificationCategory category,
        @NotNull NotificationSeverity severity,
        @NotNull NotificationStatus status
) {
}
