package com.hospease.requestdto;

import com.hospease.enums.RoomStatus;
import com.hospease.enums.RoomType;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

public record RoomRequest(
        @NotBlank String roomNumber,
        @NotNull RoomType roomType,
        @NotNull @Positive Integer capacity,
        String amenitiesJson,
        @NotNull RoomStatus status,
        @NotNull @DecimalMin("0.0") BigDecimal ratePerNight
) {
}
