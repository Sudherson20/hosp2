package com.hospease.requestdto;

import com.hospease.enums.ReservationStatus;
import jakarta.validation.constraints.NotNull;

public record ReservationStatusRequest(@NotNull ReservationStatus status) {
}
