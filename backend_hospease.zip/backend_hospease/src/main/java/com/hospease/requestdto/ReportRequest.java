package com.hospease.requestdto;

import com.hospease.enums.ReportScope;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record ReportRequest(
        @NotBlank String title,
        @NotNull ReportScope scope,
        String parametersJson,
        String reportUri
) {
}
