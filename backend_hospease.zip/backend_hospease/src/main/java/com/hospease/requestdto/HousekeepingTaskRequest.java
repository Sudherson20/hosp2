package com.hospease.requestdto;

import com.hospease.enums.HousekeepingTaskStatus;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

public record HousekeepingTaskRequest(
        @NotNull Long roomId,
        @NotNull Long assignedStaffId,
        @NotNull LocalDateTime scheduledAt,
        @NotNull HousekeepingTaskStatus status,
        String notes
) {
}
