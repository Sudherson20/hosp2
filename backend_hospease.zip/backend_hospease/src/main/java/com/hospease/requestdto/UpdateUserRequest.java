package com.hospease.requestdto;

import com.hospease.enums.RoleType;
import com.hospease.enums.UserStatus;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record UpdateUserRequest(
        @NotBlank @Size(max = 120) String name,
        @NotBlank @Email String email,
        @NotBlank @Pattern(regexp = "^[0-9+\\-]{10,20}$", message = "Phone number must be 10 to 20 digits") String phone,
        RoleType role,
        UserStatus status,
        Boolean mfaEnabled
) {
}
