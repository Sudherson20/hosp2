package com.hospease.requestdto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public record GuestRequest(
        @NotNull Long userId,
        @NotBlank String fullName,
        LocalDate dateOfBirth,
        String contactInfoJson,
        String addressJson,
        String loyaltyTier,
        @NotBlank String guestStatus
) {
}
