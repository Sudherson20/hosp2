package com.hospease.requestdto;

import com.hospease.enums.ServiceOrderStatus;
import jakarta.validation.constraints.NotNull;

public record ServiceOrderStatusRequest(@NotNull ServiceOrderStatus status) {
}
