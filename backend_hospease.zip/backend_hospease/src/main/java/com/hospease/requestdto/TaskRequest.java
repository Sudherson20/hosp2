package com.hospease.requestdto;

import com.hospease.enums.TaskPriority;
import com.hospease.enums.TaskStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

public record TaskRequest(
        @NotNull Long assignedToUserId,
        String relatedEntityId,
        String relatedEntityType,
        @NotBlank String description,
        LocalDateTime dueDate,
        @NotNull TaskPriority priority,
        @NotNull TaskStatus status
) {
}
