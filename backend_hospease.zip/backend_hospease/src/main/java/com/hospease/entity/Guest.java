package com.hospease.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "guests")
public class Guest extends BaseEntity {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Column(nullable = false, length = 120)
    private String fullName;

    private LocalDate dateOfBirth;

    @Column(columnDefinition = "TEXT")
    private String contactInfoJson;

    @Column(columnDefinition = "TEXT")
    private String addressJson;

    @Column(length = 50)
    private String loyaltyTier;

    @Column(nullable = false, length = 30)
    private String guestStatus;
}
