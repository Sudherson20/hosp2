package com.hospease.entity;

import com.hospease.enums.RoleType;
import com.hospease.enums.StaffDepartment;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "staff")
public class Staff extends BaseEntity {

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 40)
    private RoleType role;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 40)
    private StaffDepartment department;

    @Column(columnDefinition = "TEXT")
    private String contactInfoJson;

    @Column(nullable = false, length = 30)
    private String staffStatus;
}
