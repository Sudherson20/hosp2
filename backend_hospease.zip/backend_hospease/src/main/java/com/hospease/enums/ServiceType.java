package com.hospease.enums;

public enum ServiceType {
    F_AND_B,
    SPA,
    GYM,
    OTHER
}
