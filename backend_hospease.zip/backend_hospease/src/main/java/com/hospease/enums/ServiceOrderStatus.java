package com.hospease.enums;

public enum ServiceOrderStatus {
    REQUESTED,
    IN_PROGRESS,
    FULFILLED,
    CANCELLED
}
