package com.hospease.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
