package com.hospease.enums;

public enum NotificationCategory {
    RESERVATION,
    SERVICE,
    FINANCE,
    HOUSEKEEPING,
    SHIFT,
    GENERAL
}
