package com.hospease.enums;

public enum ShiftStatus {
    SCHEDULED,
    COMPLETED,
    CANCELLED
}
