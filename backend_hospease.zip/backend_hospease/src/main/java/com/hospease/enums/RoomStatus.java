package com.hospease.enums;

public enum RoomStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE,
    CLEANING
}
