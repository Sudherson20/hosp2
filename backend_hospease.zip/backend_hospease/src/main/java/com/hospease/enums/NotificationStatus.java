package com.hospease.enums;

public enum NotificationStatus {
    UNREAD,
    READ,
    ARCHIVED
}
