package com.hospease.enums;

public enum ReportScope {
    OCCUPANCY,
    FINANCE,
    STAFF,
    OPERATIONS
}
