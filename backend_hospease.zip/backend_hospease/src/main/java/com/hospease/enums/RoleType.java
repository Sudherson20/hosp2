package com.hospease.enums;

public enum RoleType {
    GUEST,
    FRONT_DESK,
    HOUSEKEEPING,
    SERVICE_STAFF,
    FINANCE,
    MANAGER,
    ADMIN,
    AUDITOR
}
