package com.hospease.enums;

public enum RoomType {
    SINGLE,
    DOUBLE,
    SUITE
}
