package com.hospease.enums;

public enum NotificationSeverity {
    LOW,
    MEDIUM,
    HIGH
}
