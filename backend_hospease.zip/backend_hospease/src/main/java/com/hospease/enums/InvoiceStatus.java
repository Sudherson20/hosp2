package com.hospease.enums;

public enum InvoiceStatus {
    UNPAID,
    OVERDUE,
    SETTLED_EXTERNALLY,
    VOID
}
