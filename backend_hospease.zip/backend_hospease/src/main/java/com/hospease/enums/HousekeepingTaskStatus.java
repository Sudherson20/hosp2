package com.hospease.enums;

public enum HousekeepingTaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
