package com.hospease.enums;

public enum StaffDepartment {
    FRONT_OFFICE,
    HOUSEKEEPING,
    SERVICE,
    FINANCE,
    MANAGEMENT,
    ADMINISTRATION
}
