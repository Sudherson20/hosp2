package com.hospease.responsedto;

import java.time.LocalDateTime;

public record AuditLogResponse(
        Long id,
        Long userId,
        String userEmail,
        String action,
        String resourceType,
        String resourceId,
        String details,
        LocalDateTime createdAt
) {
}
