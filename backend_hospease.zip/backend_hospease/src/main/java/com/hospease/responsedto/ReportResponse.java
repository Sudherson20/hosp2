package com.hospease.responsedto;

import com.hospease.enums.ReportScope;
import java.time.LocalDateTime;

public record ReportResponse(
        Long id,
        String title,
        ReportScope scope,
        String parametersJson,
        String metricsJson,
        Long generatedByUserId,
        LocalDateTime generatedAt,
        String reportUri
) {
}
