package com.hospease.responsedto;

import com.hospease.enums.TaskPriority;
import com.hospease.enums.TaskStatus;
import java.time.LocalDateTime;

public record TaskResponse(
        Long id,
        Long assignedToUserId,
        String assignedToName,
        String relatedEntityId,
        String relatedEntityType,
        String description,
        LocalDateTime dueDate,
        TaskPriority priority,
        LocalDateTime completedAt,
        TaskStatus status
) {
}
