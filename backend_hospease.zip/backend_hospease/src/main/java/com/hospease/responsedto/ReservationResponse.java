package com.hospease.responsedto;

import com.hospease.enums.ReservationStatus;
import java.time.LocalDate;

public record ReservationResponse(
        Long id,
        Long guestId,
        String guestName,
        Long roomId,
        String roomNumber,
        LocalDate checkInDate,
        LocalDate checkOutDate,
        ReservationStatus status
) {
}
