package com.hospease.responsedto;

import com.hospease.enums.HousekeepingTaskStatus;
import java.time.LocalDateTime;

public record HousekeepingTaskResponse(
        Long id,
        Long roomId,
        String roomNumber,
        Long assignedStaffId,
        String assignedStaffName,
        LocalDateTime scheduledAt,
        LocalDateTime completedAt,
        HousekeepingTaskStatus status,
        String notes
) {
}
