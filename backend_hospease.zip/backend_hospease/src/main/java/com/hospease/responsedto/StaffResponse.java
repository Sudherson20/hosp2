package com.hospease.responsedto;

import com.hospease.enums.RoleType;
import com.hospease.enums.StaffDepartment;

public record StaffResponse(
        Long id,
        Long userId,
        RoleType role,
        StaffDepartment department,
        String contactInfoJson,
        String staffStatus
) {
}
