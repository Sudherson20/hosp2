package com.hospease.responsedto;

import com.hospease.enums.RoomStatus;
import com.hospease.enums.RoomType;
import java.math.BigDecimal;

public record RoomResponse(
        Long id,
        String roomNumber,
        RoomType roomType,
        Integer capacity,
        String amenitiesJson,
        RoomStatus status,
        BigDecimal ratePerNight
) {
}
