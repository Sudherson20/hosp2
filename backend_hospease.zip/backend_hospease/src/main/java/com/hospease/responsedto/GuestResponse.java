package com.hospease.responsedto;

import java.time.LocalDate;

public record GuestResponse(
        Long id,
        Long userId,
        String fullName,
        LocalDate dateOfBirth,
        String contactInfoJson,
        String addressJson,
        String loyaltyTier,
        String guestStatus
) {
}
