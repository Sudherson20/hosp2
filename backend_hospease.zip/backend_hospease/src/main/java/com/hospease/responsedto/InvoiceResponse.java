package com.hospease.responsedto;

import com.hospease.enums.InvoiceStatus;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public record InvoiceResponse(
        Long id,
        Long guestId,
        String guestName,
        Long reservationId,
        String lineItemsJson,
        BigDecimal totalAmount,
        String currency,
        LocalDateTime issuedAt,
        LocalDate dueDate,
        InvoiceStatus status,
        String invoiceUri,
        String reconciliationNotes
) {
}
