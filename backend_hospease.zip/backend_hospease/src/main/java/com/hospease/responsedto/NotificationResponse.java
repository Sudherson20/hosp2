package com.hospease.responsedto;

import com.hospease.enums.NotificationCategory;
import com.hospease.enums.NotificationSeverity;
import com.hospease.enums.NotificationStatus;
import java.time.LocalDateTime;

public record NotificationResponse(
        Long id,
        Long userId,
        String entityId,
        String message,
        NotificationCategory category,
        NotificationSeverity severity,
        LocalDateTime readAt,
        NotificationStatus status
) {
}
