package com.hospease.responsedto;

import com.hospease.enums.RoleType;

public record AuthResponse(
        String accessToken,
        String refreshToken,
        String tokenType,
        Long userId,
        String name,
        String email,
        RoleType role
) {
}
