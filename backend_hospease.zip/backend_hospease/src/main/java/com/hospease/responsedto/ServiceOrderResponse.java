package com.hospease.responsedto;

import com.hospease.enums.ServiceOrderStatus;
import com.hospease.enums.ServiceType;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public record ServiceOrderResponse(
        Long id,
        Long guestId,
        String guestName,
        Long roomId,
        String roomNumber,
        ServiceType serviceType,
        String detailsJson,
        BigDecimal amount,
        LocalDateTime orderedAt,
        LocalDateTime fulfilledAt,
        ServiceOrderStatus status
) {
}
