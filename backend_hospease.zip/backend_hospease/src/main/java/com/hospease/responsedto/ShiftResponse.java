package com.hospease.responsedto;

import com.hospease.enums.ShiftStatus;
import java.time.LocalDateTime;

public record ShiftResponse(
        Long id,
        Long staffId,
        String staffName,
        LocalDateTime startAt,
        LocalDateTime endAt,
        Long assignedByUserId,
        ShiftStatus status
) {
}
