package com.hospease.responsedto;

import com.hospease.enums.RoleType;
import com.hospease.enums.UserStatus;
import java.time.LocalDateTime;

public record UserResponse(
        Long id,
        String name,
        String email,
        String phone,
        RoleType role,
        UserStatus status,
        boolean mfaEnabled,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
}
