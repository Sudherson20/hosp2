package com.hospease.config;

import com.hospease.entity.Guest;
import com.hospease.entity.Room;
import com.hospease.entity.Staff;
import com.hospease.entity.User;
import com.hospease.enums.RoleType;
import com.hospease.enums.RoomStatus;
import com.hospease.enums.RoomType;
import com.hospease.enums.StaffDepartment;
import com.hospease.enums.UserStatus;
import com.hospease.repository.GuestRepository;
import com.hospease.repository.RoomRepository;
import com.hospease.repository.StaffRepository;
import com.hospease.repository.UserRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@RequiredArgsConstructor
public class DataSeeder {

    private final PasswordEncoder passwordEncoder;
    private final GuestRepository guestRepository;
    private final StaffRepository staffRepository;
    private final RoomRepository roomRepository;

    @Value("${app.seed.admin-email}")
    private String adminEmail;

    @Value("${app.seed.admin-password}")
    private String adminPassword;

    @Bean
    CommandLineRunner seedUsers(UserRepository userRepository) {
        return args -> {
            if (userRepository.count() > 0) {
                return;
            }

            Map<RoleType, String> seedEmails = Map.of(
                    RoleType.ADMIN, adminEmail,
                    RoleType.MANAGER, "manager@hospease.local",
                    RoleType.FRONT_DESK, "frontdesk@hospease.local",
                    RoleType.HOUSEKEEPING, "housekeeping@hospease.local",
                    RoleType.SERVICE_STAFF, "service@hospease.local",
                    RoleType.FINANCE, "finance@hospease.local",
                    RoleType.AUDITOR, "auditor@hospease.local",
                    RoleType.GUEST, "guest@hospease.local"
            );

            long phoneBase = 9000000000L;
            int index = 0;
            for (RoleType roleType : RoleType.values()) {
                User user = new User();
                user.setName(roleType.name().replace('_', ' '));
                user.setEmail(seedEmails.get(roleType));
                user.setPhone(String.valueOf(phoneBase + index));
                user.setPassword(passwordEncoder.encode(roleType == RoleType.ADMIN ? adminPassword : "Password@123"));
                user.setRole(roleType);
                user.setStatus(UserStatus.ACTIVE);
                user.setMfaEnabled(roleType == RoleType.ADMIN || roleType == RoleType.MANAGER);
                userRepository.save(user);
                index++;
            }

            User guestUser = userRepository.findByEmail("guest@hospease.local").orElseThrow();
            Guest guest = new Guest();
            guest.setUser(guestUser);
            guest.setFullName("Default Guest");
            guest.setDateOfBirth(LocalDate.of(1995, 5, 12));
            guest.setContactInfoJson("{\"email\":\"guest@hospease.local\",\"phone\":\"9000000007\"}");
            guest.setAddressJson("{\"city\":\"Chennai\",\"country\":\"India\"}");
            guest.setLoyaltyTier("Silver");
            guest.setGuestStatus("ACTIVE");
            guestRepository.save(guest);

            createStaffProfile(userRepository, "frontdesk@hospease.local", RoleType.FRONT_DESK, StaffDepartment.FRONT_OFFICE);
            createStaffProfile(userRepository, "housekeeping@hospease.local", RoleType.HOUSEKEEPING, StaffDepartment.HOUSEKEEPING);
            createStaffProfile(userRepository, "service@hospease.local", RoleType.SERVICE_STAFF, StaffDepartment.SERVICE);
            createStaffProfile(userRepository, "finance@hospease.local", RoleType.FINANCE, StaffDepartment.FINANCE);
            createStaffProfile(userRepository, "manager@hospease.local", RoleType.MANAGER, StaffDepartment.MANAGEMENT);
            createStaffProfile(userRepository, adminEmail, RoleType.ADMIN, StaffDepartment.ADMINISTRATION);

            if (roomRepository.count() == 0) {
                roomRepository.save(buildRoom("101", RoomType.SINGLE, 1, new BigDecimal("3500")));
                roomRepository.save(buildRoom("102", RoomType.DOUBLE, 2, new BigDecimal("5500")));
                roomRepository.save(buildRoom("201", RoomType.SUITE, 4, new BigDecimal("9500")));
            }
        };
    }

    private void createStaffProfile(UserRepository userRepository, String email, RoleType roleType, StaffDepartment department) {
        User user = userRepository.findByEmail(email).orElseThrow();
        Staff staff = new Staff();
        staff.setUser(user);
        staff.setRole(roleType);
        staff.setDepartment(department);
        staff.setContactInfoJson("{\"email\":\"" + email + "\"}");
        staff.setStaffStatus("ACTIVE");
        staffRepository.save(staff);
    }

    private Room buildRoom(String roomNumber, RoomType roomType, int capacity, BigDecimal rate) {
        Room room = new Room();
        room.setRoomNumber(roomNumber);
        room.setRoomType(roomType);
        room.setCapacity(capacity);
        room.setAmenitiesJson("{\"wifi\":true,\"ac\":true}");
        room.setStatus(RoomStatus.AVAILABLE);
        room.setRatePerNight(rate);
        return room;
    }
}
