package com.hospease.repository;

import com.hospease.entity.HousekeepingTask;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HousekeepingTaskRepository extends JpaRepository<HousekeepingTask, Long> {
    List<HousekeepingTask> findByAssignedToId(Long staffId);
}
