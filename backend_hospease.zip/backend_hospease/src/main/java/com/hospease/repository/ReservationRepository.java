package com.hospease.repository;

import com.hospease.entity.Reservation;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    List<Reservation> findByGuestId(Long guestId);

    @Query("""
            select count(r) > 0 from Reservation r
            where r.room.id = :roomId
            and r.status <> com.hospease.enums.ReservationStatus.CANCELLED
            and :checkIn < r.checkOutDate
            and :checkOut > r.checkInDate
            and (:reservationId is null or r.id <> :reservationId)
            """)
    boolean hasOverlappingReservation(
            @Param("roomId") Long roomId,
            @Param("checkIn") LocalDate checkIn,
            @Param("checkOut") LocalDate checkOut,
            @Param("reservationId") Long reservationId
    );
}
