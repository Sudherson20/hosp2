package com.hospease.repository;

import com.hospease.entity.Guest;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GuestRepository extends JpaRepository<Guest, Long> {
    Optional<Guest> findByUserId(Long userId);
}
