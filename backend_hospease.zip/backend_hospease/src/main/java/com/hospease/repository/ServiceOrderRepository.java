package com.hospease.repository;

import com.hospease.entity.ServiceOrder;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceOrderRepository extends JpaRepository<ServiceOrder, Long> {
    List<ServiceOrder> findByGuestId(Long guestId);
}
